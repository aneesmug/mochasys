    </div>
</div>


<div id="footer-wrapper">
<div data-elementor-type="wp-post" data-elementor-id="3725" class="elementor custom-css-style" data-elementor-settings="[]">
    <div class="elementor-inner">
        <div class="elementor-section-wrap">
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-c7d144f elementor-section-full_width elementor-section-height-min-height elementor-section-height-default elementor-section-items-middle"
                data-id="c7d144f"
                data-element_type="section"
                data-settings='{"background_background":"classic","craftcoffee_ext_is_background_parallax":"false"}'
            >
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
                        <div
                            class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-38383f6"
                            data-id="38383f6"
                            data-element_type="column"
                            data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                        >
                            <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                    <div
                                        class="elementor-element elementor-element-c795a27 elementor-widget elementor-widget-heading"
                                        data-id="c795a27"
                                        data-element_type="widget"
                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        data-widget_type="heading.default"
                                    >
                                        <div class="elementor-widget-container">
                                            <h2 class="elementor-heading-title elementor-size-default">History</h2>
                                        </div>
                                    </div>
                                    <div
                                        class="elementor-element elementor-element-fe30d60 elementor-widget elementor-widget-text-editor"
                                        data-id="fe30d60"
                                        data-element_type="widget"
                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        data-widget_type="text-editor.default"
                                    >
                                        <div class="elementor-widget-container">
                                            <div class="elementor-text-editor elementor-clearfix">
                                                <p>
                                                    Mochachino was established in the year 2000 with just one outlet and six employees with the sole aim of serving the clients with coffee in its true form, by the Grace of Allah the almighty and the support of its patrons, Mochachino has never looked back since, today it boasts of having around 42 outlets which span throughout the sprawling and bustling Makkah al Mukarramah region, with the employees exceeding to more than 160.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div
                                        class="elementor-element elementor-element-bbbbc70 elementor-widget elementor-widget-image"
                                        data-id="bbbbc70"
                                        data-element_type="widget"
                                        data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        data-widget_type="image.default"
                                    >
                                        <div class="elementor-widget-container">
                                            <div class="elementor-image">
                                                <img
                                                    width="350"
                                                    height="49"
                                                    src="upload/singature_white-e1592385719386.png"
                                                    class="attachment-full size-full"
                                                    alt=""
                                                    loading="lazy"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div
                            class="elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ff896b7"
                            data-id="ff896b7"
                            data-element_type="column"
                            data-settings='{"background_background":"classic","craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                        >
                            <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                    <div
                                        class="elementor-element elementor-element-8af6019 elementor-widget__width-auto elementor-absolute elementor-widget elementor-widget-image"
                                        data-id="8af6019"
                                        data-element_type="widget"
                                        data-settings='{"_position":"absolute","craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                        data-widget_type="image.default"
                                    >
                                        <div class="elementor-widget-container">
                                            <div class="elementor-image">
                                                <img
                                                    width="340"
                                                    height="340"
                                                    src="upload/since_2000.png"
                                                    class="attachment-full size-full"
                                                    alt=""
                                                    loading="lazy"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-9229aee elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                data-id="9229aee"
                data-element_type="section"
                data-settings='{"background_background":"classic","craftcoffee_ext_is_background_parallax":"false"}'
            >
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
                        <div
                            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-2cba03a"
                            data-id="2cba03a"
                            data-element_type="column"
                            data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                        >
                            <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                    <section
                                        class="elementor-section elementor-inner-section elementor-element elementor-element-7e367f8 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
                                        data-id="7e367f8"
                                        data-element_type="section"
                                        data-settings='{"craftcoffee_ext_is_background_parallax":"false"}'
                                    >
                                        <div class="elementor-container elementor-column-gap-default">
                                            <div class="elementor-row">
                                                <div
                                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-4d8e803"
                                                    data-id="4d8e803"
                                                    data-element_type="column"
                                                    data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                >
                                                    <div class="elementor-column-wrap elementor-element-populated">
                                                        <div class="elementor-widget-wrap">
                                                            <div
                                                                class="elementor-element elementor-element-658e32a elementor-widget__width-auto elementor-widget elementor-widget-image"
                                                                data-id="658e32a"
                                                                data-element_type="widget"
                                                                data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                data-widget_type="image.default"
                                                            >
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-image">
                                                                        <img
                                                                            width="124"
                                                                            height="124"
                                                                            src="upload/icon_vintage_phone.png"
                                                                            class="attachment-full size-full"
                                                                            alt=""
                                                                            loading="lazy"
                                                                        />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="elementor-element elementor-element-e3d4439 elementor-widget__width-auto elementor-widget elementor-widget-text-editor"
                                                                data-id="e3d4439"
                                                                data-element_type="widget"
                                                                data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                data-widget_type="text-editor.default"
                                                            >
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-text-editor elementor-clearfix">
                                                                        <p class="p1">
                                                                            <span class="s1">
                                                                                Openning Hours <br />
                                                                                08.30AM – 4.30PM
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-8d59401"
                                                    data-id="8d59401"
                                                    data-element_type="column"
                                                    data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                >
                                                    <div class="elementor-column-wrap elementor-element-populated">
                                                        <div class="elementor-widget-wrap">
                                                            <div
                                                                class="elementor-element elementor-element-03d2b2d elementor-widget__width-auto elementor-widget elementor-widget-image"
                                                                data-id="03d2b2d"
                                                                data-element_type="widget"
                                                                data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                                data-widget_type="image.default"
                                                            >
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-image">
                                                                        <img
                                                                            width="124"
                                                                            height="160"
                                                                            src="upload/icon_vintage_compass.png"
                                                                            class="attachment-full size-full"
                                                                            alt=""
                                                                            loading="lazy"
                                                                        />
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div
                                                                class="elementor-element elementor-element-5662f5b elementor-widget__width-auto elementor-widget elementor-widget-text-editor"
                                                            >
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-text-editor elementor-clearfix">
                                                                        <p class="p1">
                                                                            <span class="s1">
                                                                                Location: Prince Sultan Street<br />
                                                                                Opp. Site Arab National Schools
                                                                                <br />
                                                                                Al Basateen, Jeddah, Saudi Arabia
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div
                                                    class="elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-06fc5ca"
                                                    data-id="06fc5ca"
                                                    data-element_type="column"
                                                    data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
                                                >
                                                    <div class="elementor-column-wrap elementor-element-populated">
                                                        <div class="elementor-widget-wrap">
                                                            <div
                                                                class="elementor-element elementor-element-9c89ed9 elementor-widget__width-auto elementor-shape-rounded elementor-grid-0 elementor-widget elementor-widget-social-icons"
                                                            >
                                                                <div class="elementor-widget-container">
                                                                    <div class="elementor-social-icons-wrapper elementor-grid">
                                                                        <div class="elementor-grid-item">
                                                                            <a href="www.tiktok.com/@mochachinoksa1" class="elementor-icon elementor-social-icon elementor-social-icon-tiktok elementor-repeater-item-fac257c" target="_blank">
                                                                                <span class="elementor-screen-only">Tiktok</span>
                                                                                <i class="fab fa-tiktok"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="elementor-grid-item">
                                                                            <a href="https://www.instagram.com/mochachinoksa1/" class="elementor-icon elementor-social-icon elementor-social-icon-instagram elementor-repeater-item-4238c6b" target="_blank">
                                                                                <span class="elementor-screen-only">Instagram</span>
                                                                                <i class="fab fa-instagram"></i>
                                                                            </a>
                                                                        </div>
                                                                        <div class="elementor-grid-item">
                                                                            <a href="https://twitter.com/mochachinoksa1" class="elementor-icon elementor-social-icon elementor-social-icon-twitter elementor-repeater-item-e0f5af3" target="_blank">
                                                                                <span class="elementor-screen-only">Twitter</span>
                                                                                <i class="fab fa-twitter"></i>
                                                                            </a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </section>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section
                class="elementor-section elementor-top-section elementor-element elementor-element-3374de8 elementor-section-boxed elementor-section-height-default elementor-section-height-default"
            >
                <div class="elementor-container elementor-column-gap-default">
                    <div class="elementor-row">
                        <div
                            class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-58c7cfc"
                        >
                            <div class="elementor-column-wrap elementor-element-populated">
                                <div class="elementor-widget-wrap">
                                    <div
                                        class="elementor-element elementor-element-ebb6c30 elementor-widget elementor-widget-heading">
                                        <div class="elementor-widget-container">
                                            <h3 class="elementor-heading-title elementor-size-default">
                                            <?php echo $site_footer ?>
                                        </h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

</div>
    <a id="go-to-top" href="javascript:;"><span class="ti-arrow-up"></span></a>
</div>


    <script type="text/javascript" src="js/jquery.js" ></script>
    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js" ></script> -->
    <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCYitdRZ4kpKRySDphh22FCRXoLwHqP_Ok"></script> -->
    <!-- <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?language=en&key=AIzaSyA-AB-9XZd-iQby-bNLYPFyb0pR2Qw3orw"></script> -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBQbnrTvBW0ML5bVlgsgMhYCqdRR04d7k0&callback=initMap&libraries=&v=weekly"></script>
    <script type="text/javascript" src="js/ui/core.min.js" ></script>
    <script type="text/javascript" src="js/ui/datepicker.min.js" ></script>

    

<script>
function initMap() {
var map;
var bounds = new google.maps.LatLngBounds();
var mapOptions = {
mapTypeId: 'roadmap'
};
// Display a map on the web page
map = new google.maps.Map(document.getElementById("mapCanvas"), mapOptions);
map.setTilt(100);
// Multiple markers location, latitude, and longitude
var markers = [
<?php if(mysqli_num_rows($query_loc) > 0){ 
while($row = mysqli_fetch_assoc($query_loc)){ 
// echo '["'.$row['location_name'].'", '.$row['latitude'].', '.$row['longitude'].', "'.$row['icon'].'"],'; 
echo '["'.$row['location_name'].'", '.$row['latitude'].', '.$row['longitude'].', "./upload/map-maker.png"],'; 
} 
} 
?>
];
// Info window content
var infoWindowContent = [
<?php if(mysqli_num_rows($query_loc) > 0){ 
while($row = mysqli_fetch_assoc($query_loc)){ ?>
['<div class="info_content">' +
'<h3><?php echo $row['location_name']; ?></h3>' +
'<p><?php echo $row['section_name']; ?></p>' + '</div>'],
<?php } 
} 
?>
];
// Add multiple markers to map
var infoWindow = new google.maps.InfoWindow(), marker, i;
// Place each marker on the map 
for( i = 0; i < markers.length; i++ ) {
var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
bounds.extend(position);
marker = new google.maps.Marker({
position: position,
map: map,
icon: markers[i][3],
title: markers[i][0]
});
// Add info window to marker 
google.maps.event.addListener(marker, 'click', (function(marker, i) {
return function() {
infoWindow.setContent(infoWindowContent[i][0]);
infoWindow.open(map, marker);
}
})(marker, i));
// Center the map to fit all markers on the screen
map.fitBounds(bounds);
}
// Set zoom level
var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
this.setZoom(10);
google.maps.event.removeListener(boundsListener);
});
}
// Load initialize function
google.maps.event.addDomListener(window, 'load', initMap);
</script>






    <script type="text/javascript">
        jQuery(document).ready(function (jQuery) {
            jQuery.datepicker.setDefaults({
                closeText: "Close",
                currentText: "Today",
                monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                nextText: "Next",
                prevText: "Previous",
                dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                dayNamesMin: ["S", "M", "T", "W", "T", "F", "S"],
                dateFormat: "MM d, yy",
                firstDay: 1,
                isRTL: false,
            });
        });
    </script>
    <script type="text/javascript" src="js/imagesloaded.min.js"></script>
    <script type="text/javascript" src="js/masonry.min.js"></script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/jquery.lazy.js"></script>
    <script type="text/javascript">
        jQuery(function ($) {
            jQuery("img.lazy").each(function () {
                var currentImg = jQuery(this);

                jQuery(this).Lazy({
                    onFinishedAll: function () {
                        currentImg.parent("div.post-featured-image-hover").removeClass("lazy");
                        currentImg.parent(".craftcoffee_gallery_lightbox").parent("div.gallery_grid_item").removeClass("lazy");
                        currentImg.parent("div.gallery_grid_item").removeClass("lazy");
                    },
                });
            });
        });
    </script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/modulobox.js"></script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/jquery.parallax-scroll.js"></script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/jquery.smoove.js"></script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/parallax.js"></script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/jarallax.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function () {
            jQuery(".themegoods-parallax").jarallax({
                speed: 0.8,
            });
        });
    </script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/jquery.sticky-kit.min.js"></script>
    <script type="text/javascript">
        jQuery(function ($) {
            jQuery("#page-content-wrapper .sidebar-wrapper").stick_in_parent({ offset_top: 100 });

            if (jQuery(window).width() < 768 || is_touch_device()) {
                jQuery("#page-content-wrapper .sidebar-wrapper").trigger("sticky_kit:detach");
            }
        });
    </script>
    <script type="text/javascript">
        /* <![CDATA[ */
        var tgAjax = { ajaxurl: "#", ajax_nonce: "ab2451ad72" };
        /* ]]> */
    </script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/craftcoffee-elementor.js"></script>
    <script type="text/javascript" src="js/ui/effect.min.js"></script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/tweenmax.min.js"></script>
    <script type="text/javascript" src="js/plugins/waypoints.min.js"></script>
    <script type="text/javascript" src="js/plugins/jquery-stellar.js"></script>
    <script type="text/javascript">
        /* <![CDATA[ */
        var craftcoffeePluginParams = { backTitle: "Back" };
        /* ]]> */
    </script>
    <script type="text/javascript" src="js/plugins/craftcoffee-plugins.js"></script>
    <script type="text/javascript">
        /* <![CDATA[ */
        var tgAjax = { ajaxurl: "#" };
        var craftcoffeeParams = { menulayout: "leftalign", fixedmenu: "1", footerreveal: "", headercontent: "content", lightboxthumbnails: "thumbnail", lightboxtimer: "7000" };
        /* ]]> */
    </script>
    <script type="text/javascript" src="js/plugins/craftcoffee-custom.js"></script>
    <script type="text/javascript" src="js/plugins/jquery-tooltipster.js"></script>
    <script type="text/javascript">
        jQuery(function ($) {
            jQuery(".demotip").tooltipster({
                position: "left",
                multiple: true,
                theme: "tooltipster-shadow",
                delay: 0,
            });
        });
    </script>
    <script type="text/javascript" src="js/plugins/loftloader/assets/js/loftloader.min.js"></script>
    <script type="text/javascript" src="js/plugins/webfont.js"></script>
    <script type="text/javascript">
        WebFont.load({ google: { families: ["Roboto:400", "Oswald:500"] } });
    </script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/flickity.pkgd.js"></script>
    <script type="text/javascript" src="js/plugins/elementor/assets/js/frontend-modules.min.js"></script>
    <script type="text/javascript" src="js/ui/position.min.js"></script>
    <script type="text/javascript" src="js/plugins/elementor/assets/lib/dialog/dialog.min.js"></script>
    <script type="text/javascript" src="js/plugins/elementor/assets/lib/waypoints/waypoints.min.js"></script>
    <script type="text/javascript" src="js/plugins/elementor/assets/lib/swiper/swiper.min.js"></script>

    <script type='text/javascript' src='js/plugins/craftcoffee-elementor/assets/js/justifiedGallery.js'></script>
    <script type="text/javascript" src="js/plugins/craftcoffee-elementor/assets/js/switchery.js?ver=5.5.3"></script>
    <script type='text/javascript' src='js/plugins/craftcoffee-elementor/assets/js/tilt.jquery.js' id='tilt-js'></script>


    <script type="text/javascript">
        var elementorFrontendConfig = {
            environmentMode: { edit: false, wpPreview: false },
            i18n: {
                shareOnFacebook: "Share on Facebook",
                shareOnTwitter: "Share on Twitter",
                pinIt: "Pin it",
                download: "Download",
                downloadImage: "Download image",
                fullscreen: "Fullscreen",
                zoom: "Zoom",
                share: "Share",
                playVideo: "Play Video",
                previous: "Previous",
                next: "Next",
                close: "Close",
            },
            is_rtl: false,
            breakpoints: { xs: 0, sm: 480, md: 768, lg: 1025, xl: 1440, xxl: 1600 },
            version: "3.0.11",
            is_static: false,
            legacyMode: { elementWrappers: true },
            urls: { assets: "https:\/\/themes.themegoods.com\/craft\/wp-content\/plugins\/elementor\/assets\/" },
            settings: { page: [], editorPreferences: [] },
            kit: {
                global_image_lightbox: "yes",
                lightbox_enable_counter: "yes",
                lightbox_enable_fullscreen: "yes",
                lightbox_enable_zoom: "yes",
                lightbox_enable_share: "yes",
                lightbox_title_src: "title",
                lightbox_description_src: "description",
            },
            post: { id: 4462, title: "Craft%20%7C%20Cafes%20Coffee%20Shops%20Bars%20WordPress%20%E2%80%93%20Just%20another%20WordPress%20site", excerpt: "", featuredImage: false },
        };
    </script>
    <script type="text/javascript" src="js/plugins/elementor/assets/js/frontend.min.js"></script>
</body>
</html>