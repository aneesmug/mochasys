<?php include('./includes/menu.php'); ?>
<!-- Begin content -->
<div id="page-content-wrapper" class="no-title">
<div class="inner">
<!-- Begin main content -->
<div class="inner-wrapper">
<div class="sidebar-content fullwidth">
<div data-elementor-type="wp-page" data-elementor-id="3583" class="elementor custom-css-style" data-elementor-settings="[]">
<div class="elementor-inner">
<div class="elementor-section-wrap">
<section
class="elementor-section elementor-top-section elementor-element elementor-element-527efcc elementor-section-stretched elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle"
data-id="527efcc"
data-element_type="section"
data-settings='{"stretch_section":"section-stretched","background_background":"classic","craftcoffee_ext_is_background_parallax":"true","craftcoffee_ext_is_background_parallax_speed":{"unit":"px","size":0.8000000000000000444089209850062616169452667236328125,"sizes":[]}}'
>
<div class="elementor-background-overlay"></div>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div
class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-4eb3660"
data-id="4eb3660"
data-element_type="column"
data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
>
<div class="elementor-column-wrap elementor-element-populated">
    <div class="elementor-widget-wrap">
        <div
            class="elementor-element elementor-element-38763c4 elementor-widget elementor-widget-heading"
            data-id="38763c4"
            data-element_type="widget"
            data-settings='{"craftcoffee_ext_is_smoove":"true","craftcoffee_ext_smoove_disable":"769","craftcoffee_ext_smoove_duration":1000,"craftcoffee_ext_smoove_scalex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_scaley":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatey":{"unit":"px","size":100,"sizes":[]},"craftcoffee_ext_is_fadeout_animation":"true","craftcoffee_ext_is_fadeout_animation_velocity":{"unit":"px","size":0.299999999999999988897769753748434595763683319091796875,"sizes":[]},"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_smoove_rotatex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_rotatey":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_rotatez":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatez":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_skewx":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_skewy":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_perspective":{"unit":"px","size":1000,"sizes":[]},"craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation_direction":"up"}'
            data-widget_type="heading.default"
        >
            <div class="elementor-widget-container">
                <h3 class="elementor-heading-title elementor-size-default">Gallery</h3>
            </div>
        </div>
        <div
            class="elementor-element elementor-element-31fa868 elementor-widget elementor-widget-heading"
            data-id="31fa868"
            data-element_type="widget"
            data-settings='{"craftcoffee_ext_is_smoove":"true","craftcoffee_ext_smoove_disable":"769","craftcoffee_ext_smoove_duration":1000,"craftcoffee_ext_smoove_scalex":{"unit":"px","size":2,"sizes":[]},"craftcoffee_ext_smoove_scaley":{"unit":"px","size":2,"sizes":[]},"craftcoffee_ext_is_fadeout_animation":"true","craftcoffee_ext_is_fadeout_animation_direction":"down","craftcoffee_ext_is_fadeout_animation_velocity":{"unit":"px","size":0.5,"sizes":[]},"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_smoove_rotatex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_rotatey":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_rotatez":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatex":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatey":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_translatez":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_skewx":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_skewy":{"unit":"px","size":0,"sizes":[]},"craftcoffee_ext_smoove_perspective":{"unit":"px","size":1000,"sizes":[]},"craftcoffee_ext_is_infinite":"false"}'
            data-widget_type="heading.default"
        >
            <div class="elementor-widget-container">
                <h1 class="elementor-heading-title elementor-size-default">Justified</h1>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</section>
<section
class="elementor-section elementor-top-section elementor-element elementor-element-0be17b9 elementor-section-stretched elementor-section-full_width elementor-section-height-default elementor-section-height-default"
data-id="0be17b9"
data-element_type="section"
data-settings='{"stretch_section":"section-stretched","craftcoffee_ext_is_background_parallax":"false"}'
>
<div class="elementor-container elementor-column-gap-default">
<div class="elementor-row">
<div
class="elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-f4f4482"
data-id="f4f4482"
data-element_type="column"
data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
>
<div class="elementor-column-wrap elementor-element-populated">
    <div class="elementor-widget-wrap">
        <div
            class="elementor-element elementor-element-9d4024c elementor-widget elementor-widget-craftcoffee-gallery-justified"
            data-id="9d4024c"
            data-element_type="widget"
            data-settings='{"craftcoffee_ext_is_scrollme":"false","craftcoffee_ext_is_smoove":"false","craftcoffee_ext_is_parallax_mouse":"false","craftcoffee_ext_is_infinite":"false","craftcoffee_ext_is_fadeout_animation":"false"}'
            data-widget_type="craftcoffee-gallery-justified.default"
        >
            <div class="elementor-widget-container">
                <div class="craftcoffee-gallery-grid-content-wrapper do-justified justified-gallery" data-row_height="200" data-margin="5" data-justify_last_row="yes">
                    <?php                            
                        $query_gallery = mysqli_query($conDB, "SELECT * FROM `gallery` ORDER BY RAND()");
                        while ($row = mysqli_fetch_array($query_gallery)) {
                    ?>
                    <!-- <div class="entry gallery-grid-item smoove fade-in" data-delay="150" data-minwidth="769" data-opacity="0"> -->
                    <div class="entry gallery-grid-item smoove fade-in" data-opacity="0">
                        <a
                            class="craftcoffee_gallery_lightbox"
                            href="./../public/app-assets/assets/gallery/<?=$row['image'];?>"
                            data-thumb="./../public/app-assets/assets/gallery/<?=$row['image'];?>"
                            data-rel="tg_gallery9d4024c"
                            data-title="<?=$row['details'];?>"
                        >
                            <img src="./../public/app-assets/assets/gallery/<?=$row['image'];?>" class="" alt="" />
                            <div class="bg-overlay"></div>
                            <div class="gallery-grid-title"><?=$row['details'];?></div>
                        </a>
                    </div>
                <?php } ?>
                    <br class="clear" />
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</section>
</div>
</div>
</div>
<div class="comment_disable_clearer"></div>
</div>
</div>
<!-- End main content -->